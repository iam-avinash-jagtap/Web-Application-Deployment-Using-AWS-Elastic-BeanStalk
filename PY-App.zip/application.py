import logging.handlers

# Create logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Handler 
LOG_FILE = '/tmp/sample-app.log'
handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1048576, backupCount=5)
handler.setLevel(logging.INFO)

# Formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# Add Formatter to Handler
handler.setFormatter(formatter)

# add Handler to Logger
logger.addHandler(handler)

welcome = """
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>Welcome to Techaj</title>
  <style>
  body {
    color: #ffffff;
    background-color: #1e1e2f;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-size:14px;
    text-shadow: none;
    margin: 0;
  }
  .container {
    display: flex;
    height: 100vh;
    width: 100%;
  }
  .left-panel {
    width: 50%;
    padding: 4em;
    background: linear-gradient(to bottom right, #007F73, #38B000);
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: center;
    text-align: right;
  }
  .right-panel {
    width: 50%;
    padding: 4em;
    background-color: #f5f5f5;
    color: #333;
  }
  h1 {
    font-size: 4em;
    margin-bottom: 0.3em;
  }
  h2 {
    font-size: 2em;
    margin-bottom: 0.5em;
  }
  p {
    font-size: 1.2em;
    line-height: 1.5;
  }
  ul {
    list-style-type: none;
    padding-left: 0;
  }
  li {
    margin: 1em 0;
  }
  a {
    color: #0077cc;
    text-decoration: none;
  }
  a:hover {
    text-decoration: underline;
  }
  </style>
</head>
<body>
  <div class="container">
    <div class="left-panel">
      <h1>Welcome to Techaj</h1>
      <p>Your first AWS Elastic Beanstalk Python application is now live in your own environment, powered by the AWS Cloud.</p>
      <p>Techaj empowers developers to launch fast and scale smart with modern cloud tools.</p>
    </div>
    <div class="right-panel">
      <h2>Explore Techaj Resources</h2>
      <ul>
        <li><a href="http://docs.amazonwebservices.com/elasticbeanstalk/latest/dg/">Elastic Beanstalk Overview</a></li>
        <li><a href="http://docs.amazonwebservices.com/elasticbeanstalk/latest/dg/index.html?concepts.html">Concepts of AWS Beanstalk</a></li>
        <li><a href="http://docs.amazonwebservices.com/elasticbeanstalk/latest/dg/create_deploy_Python_django.html">Deploy Django App with AWS</a></li>
        <li><a href="http://docs.amazonwebservices.com/elasticbeanstalk/latest/dg/create_deploy_Python_flask.html">Deploy Flask App with AWS</a></li>
        <li><a href="http://docs.amazonwebservices.com/elasticbeanstalk/latest/dg/create_deploy_Python_custom_container.html">Customize Python Containers</a></li>
        <li><a href="http://docs.amazonwebservices.com/elasticbeanstalk/latest/dg/using-features.loggingS3.title.html">Enable Log Streaming</a></li>
      </ul>
    </div>
  </div>
</body>
</html>
"""

def application(environ, start_response):
    path = environ['PATH_INFO']
    method = environ['REQUEST_METHOD']
    if method == 'POST':
        try:
            if path == '/':
                request_body_size = int(environ['CONTENT_LENGTH'])
                request_body = environ['wsgi.input'].read(request_body_size)
                logger.info("Received a message.")
            elif path == '/scheduled':
                logger.info("Received task %s scheduled at %s", environ['HTTP_X_AWS_SQSD_TASKNAME'],
                            environ['HTTP_X_AWS_SQSD_SCHEDULED_AT'])
        except (TypeError, ValueError):
            logger.warning('Error retrieving request body for async work.')
        response = ''
    else:
        response = welcome
    start_response("200 OK", [
        ("Content-Type", "text/html"),
        ("Content-Length", str(len(response)))
    ])
    return [bytes(response, 'utf-8')]
